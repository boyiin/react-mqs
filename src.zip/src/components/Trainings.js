import React from 'react'
import image from '../img/oracle.png'
import image1 from '../img/python.png'
import image2 from '../img/android.png'
import image3 from '../img/cisco.png'

function Trainings() {
    return (
         <div className="training">
          <div className="train">
            <h3>Upcoming Training</h3>
          </div>
              <div className="imgg">
              <img src={image} alt="image" />
               
                  <p>Introduction to training <br/> Programme on Oracle <br/> Batch No: 06 <br/> Deadline: 23 May,2020 <br/> Course Fee Tk:18000.00</p>
                    <button>Details</button>
                </div>
                
                <div className ="imgg">
                <img src={image1} alt="image" />
                  
                  <p>Introduction to Training <br/> Programme on Python <br/> Batch No: 06 <br/> Deadline: 23 May,2020 <br/> Course Fee Tk:18000.00</p>
                    <button>Details</button>
                </div>
              
                <div className ="imgg">
                <img src={image2} alt="image" />
                  
                  <p>Professional Android <br/> Application Development <br/> Batch No: 06 <br/> Deadline: 23 May,2020 <br/> Course Fee Tk:18000.00</p>
                    <button>Details</button>
                </div>

                <div className="imgg">
                <img src={image3} alt="image" />
                    <p>Server and Internet Security <br/> Administrator <br/> Batch No: 06 <br/> Deadline: 23 May,2020 <br/> Course Fee Tk:18000.00</p>
                    <button>Details</button>
                </div>
        </div>
    )
}

export default Trainings
