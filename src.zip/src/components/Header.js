import React from 'react'
import image from '../img/slide.png'

function Header() {
    return (
        <div>
            <div className="slider">
            <div className="left">
            <h2>Website Design <br/> Free Course</h2>
            <h6>one of the activities of Bangladesh Computer <br/> Council (BCC) is to 
                developtrained manpower <br/> in the field of ICT through ICT training.</h6>
            </div>
                    <button type="button" className="btn btn-primary">ENROLL NOW</button>
                
                 <div className="right">
                 <img src={image} alt="image" />
                </div>
            </div>
        </div>

    )
}

export default Header
