import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

import Header from './components/Header'
import Navbar from './components/Navbar'
import Message from './components/Message'
import Trainings from './components/Trainings'

function App() {
  return (
    <div>
    <Navbar />
    <Header/>
    <Message />
    <Trainings />
    </div>
  );
}

export default App;
